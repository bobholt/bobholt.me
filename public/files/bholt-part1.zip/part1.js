/**
Lays out events for a single  day

@param array  events
	An array of event objects. Each event object consists of a start time, end
	Time (measured in minutes) from 9am, as well as a unique id. The
	Start and end time of each event will be [0, 720]. The start time will
	Be less than the end time.  The array is not sorted.

@return array
	An array of event objects that has the width, the left and top positions set,
	In addition to start time, end time, and id.

**/
function layOutDay(events){

	// Defined variables
	var FULLWIDTH = 600; // Full width of the calendar (given as constant in puzzle)
	var FULLHEIGHT = 720; // Full height of the calendar (given as constant in puzzle)

	var collisions; // All collisions between events we'll need to consider

	// Sort events by end time
	events.sort(sortByEndTime);

	// Get all of the collisions between events
	collisions = getCollisions(events);

	// Sort collisions by number at each collision point
	// This ensures we make the events as narrow as they need to be
	collisions.sort(sortByNumberOfCollisions);

	// Set the widths and positions on all of the events and return the updated object
	return setWidthsAndPositions(events, collisions);



	/**
	Converts an object containing our collisions to an array which will allow us to sort and order

	@param object  collisions
		An object consisting of key:value pairs as collisionPoint:[eventArrayIndices]

	@return array
		An array of arrays in the form [[collisionTime, [eventArrayIndices]]]

	**/
	function convertCollisionsToArray(collisions) {

		var collisionTime; // The variable we will use for each key
		var collisionsArr = []; // The array we will fill with all the collisions

		// Loop through all of the collisions in the object we passed
		for (collisionTime in collisions) {

			// Make sure we don't push any prototype properties
			if (collisions.hasOwnProperty(collisionTime)) {

				// push on a new array consisting of the [key, value]
				collisionsArr.push([collisionTime, collisions[collisionTime]]);

			}

		}

		// return our array
		return collisionsArr;

	}



	/**
	Runs through all of the events and collects lists of all collisions

	@param array  events
		An array of event objects. Each event object consists of a start time, end
		Time (measured in minutes) from 9am, as well as a unique id. The
		Start and end time of each event will be [0, 720]. The start time will
		Be less than the end time.  The array is not sorted.

	@return array
		An array of arrays of collisions in the form [[collisionTime, [eventArrayIndices]]]

	**/
	function getCollisions(events) {

		// Variables to assign later
		var i, j, currentEvent, previousEvent, collisionPoint, trackedCollisions;

		var collisionsObj = {}; // empty object to hold our collisions - object offers easier access while we build it
		var numEvents = events.length; // Cache the total number of events

		// Loop through and set intersecting events
		for (i = 0; i < numEvents; i++) {

			// Cache the current event
			currentEvent = events[i];

			// Our while loop will work backwards through the previous events, so set its iterator to our current i
			j = i;

			// Number of pixels from the top is the start time in minutes
			currentEvent.top = currentEvent.start;

			// Default the event to left-aligned
			currentEvent.left = 0;

			// Default the event to full-width
			currentEvent.width = FULLWIDTH;

			// Iterate j first to get previous event
			// Break Condition 1: we're out of events (j < 0)
			// Break Condition 2: the previous event ends before (or at the same time) our current event begins (this is why we sorted the events by end time)
			// The assumption here is that an event ending at 7:00pm would not create a collision with an event beginning at 7:00pm
			while(--j >= 0 && events[j].end > currentEvent.start) {

				// cache this object
				previousEvent = events[j];

				// When creating our collisions object, we use the current event's start time as a key
				// The value at the key is an array of the event positions within the events array that collide at that start time
				// We're not going to re-sort the events array, so we can confidently re-use those to access the same event


				// There are several conditions that could be true if two events collided. We cleared one above (events[j].end > currentEvent.start)
				if (previousEvent.start <= currentEvent.start || // If the previous event starts before or at the same time as the current event
						previousEvent.end >= currentEvent.end || // or the previous event ends after or at the same time as the current event
						(previousEvent.start > currentEvent.start && previousEvent.end < currentEvent.end) // or the previous event starts after our current event starts AND ends before our current event ends
				) {

					// Our collision point is the later of the two start times - the place they actually collide
					collisionPoint = Math.max(previousEvent.start, currentEvent.start);

					// Cache this array, because we're going to access it a lot
					trackedCollisions = collisionsObj[collisionPoint];

					// If there's an array on this key use it, otherwise create a new one
					trackedCollisions = trackedCollisions || [];

					// Let's just make sure we haven't added this event yet - this can happen if many events have the same start time
					if (trackedCollisions.indexOf(i) === -1) {

						// Add the position of the event in the array to the collisions at this start time
						trackedCollisions.push(i);

					}

					// Check to make sure we haven't added the previous event
					if (trackedCollisions.indexOf(j) === -1) {

						// Add the position of the event in the array to the collisions at this start time
						trackedCollisions.push(j);

					}

					// Write this back to our collisionsObject
					collisionsObj[collisionPoint] = trackedCollisions;

				}

			}

		}

		// We kept the collisions in an object for easy access - we're going to move them to an array for sorting purposes and return that
		return convertCollisionsToArray(collisionsObj);

	}



	/**
	Calculates what the events' widths and left positions should be and sets them

	@param array  events
		An array of event objects. Each event object consists of a start time, end
		Time (measured in minutes) from 9am, as well as a unique id. The
		Start and end time of each event will be [0, 720]. The start time will
		Be less than the end time.  The array is not sorted.

	@param array  collisionsArr
		An array of arrays of all collisions in the form [[collisionTime, [eventArrayIndices]]]

	@return array events
		An array of event objects modified to include left position and width parameters

	**/
	function setWidthsAndPositions(events, collisionsArr) {

		// Variables to assign later
		var k, l, m, collision, numCollisions, minWidth, usedLefts, eventToCheck, eventToModify;

		// Loop through all of our collisions
		for (l = 0; l < collisionsArr.length; l++) {

			// cache the current collision
			collision = collisionsArr[l][1];

			// Sort the collisions by longest in duration to make sure we get the left positions locked correctly
			collision.sort(sortByEventDuration);

			// cache the number of collisions at this point
			numCollisions = collision.length;

			// Reset our minimum width tracker to the maximum width each event can be to fit
			// Based on our sorting, we know collision[0].width would be the narrowest of all the ones in this loop
			minWidth = FULLWIDTH / numCollisions;

			// reset used left positions object
			usedLefts = {};

			// Loop through existing to see if there's a narrower width
			// If so, all of these need to be at that width, too, per constraint 1, below
			// Constraint 1: Every colliding event must be the same width as every other event that it collides width
			for (k = 0; k < numCollisions; k++) {

				// Cache the event here, because we'll refer to it a lot
				eventToCheck = events[collision[k]];

				// Make sure our width is at the narrowest from this collection
				minWidth = Math.min(eventToCheck.width, minWidth);

				// Check to see if this event's position is locked. If so, add it to the list of used left positions
				if (eventToCheck.leftLocked) {

					// If this already exists in the list of left positions, reset it, because it's overlapping something else
					if (usedLefts[eventToCheck.left]) {

						// Reset left position to zero
						eventToCheck.left = 0;

					}

					// Add this to the list of use left positions
					usedLefts[eventToCheck.left] = true;

				}

			}

			// Loop through again (ugh) to set widths and left positions
			for (m = 0; m < numCollisions; m++) {

				// Cache the event here, because we'll refer to it a lot
				eventToModify = events[collision[m]];

				// Figure out what the left should be if we were just assigning it
				var leftShouldBe = FULLWIDTH - ((1 + m) * minWidth);

				// If the left is 0 by default (not assigned and locked)
				if (eventToModify.left === 0 && !eventToModify.leftLocked) {

					// Check the position we want to assign to see if it's used
					while (usedLefts[leftShouldBe]) {

						// Step back through positions until we find one that works
						leftShouldBe = leftShouldBe - minWidth;

					}

				// Otherwise, the event has already been assigned a left position
				} else {

					// The left position should be what was already assigned
					leftShouldBe = eventToModify.left;

				}

				// Add this left to our tracking object
				usedLefts[leftShouldBe] = true;

				// Set our event's width
				eventToModify.width = minWidth;

				// Set our event's left position
				eventToModify.left = leftShouldBe;

				// Designate our left position as assigned and "locked"
				eventToModify.leftLocked = true;

			}

		}

		// Return the modified events array
		return events;

	}



	/**
	Sorts by event End Time (ascending)

	@param object  a
		An object with an end parameter to compare

	@param object  b
		An object with an end parameter to compare

	@return number
		A number indicating sort order

	**/
	function sortByEndTime(a, b) {

		// Sort ascending
		// This will be important in our while loop below
		return a.end - b.end;

	}




	/**
	Sorts by event duration (descending)

	@param number  a
		An index of an event in the events array

	@param number  b
		An index of an event in the events array

	@return number
		A number indicating sort order

	**/
	function sortByEventDuration(a, b) {

		// Sort by duration (descending)
		return ((events[b].end - events[b].start) - (events[a].end - events[a].start));

	}




	/**
	Sorts by total number of collisions at a point (descending)

	@param array  a
		An array of collision points

	@param array  b
		An array of collision points

	@return number
		A number indicating sort order

	**/
	function sortByNumberOfCollisions(a, b){

		// Sort descending
		return (b[1].length - a[1].length);

	}

}