/*global module:false*/
module.exports = function(grunt) {

  var deploydir = '../publish/';
  var baseDir = '../';
  var imageDir = 'img/';

  // Project configuration.
  grunt.initConfig({
    // meta, clean, copy, lint, concat, min, mincss, processhtml, watch, jshint, uglify,

    img: {
      dist: [deploydir + imageDir + '**/*']
    }

  });

  grunt.loadTasks('tasks');

  // Default task.
  grunt.registerTask('default', 'clean lint copy concat min mincss img processhtml');

};
